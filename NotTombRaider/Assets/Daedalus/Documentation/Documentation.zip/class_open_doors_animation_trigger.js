var class_open_doors_animation_trigger =
[
    [ "AnimateClose", "class_open_doors_animation_trigger.html#a031f335fb40e430953b015a8ae8dd56d", null ],
    [ "AnimateOpen", "class_open_doors_animation_trigger.html#a221dd15334366341b1860c7462ba8716", null ],
    [ "animationSpeed", "class_open_doors_animation_trigger.html#ad8e1e2ee1588bc419df5c254dcc906c0", null ],
    [ "doors_animation", "class_open_doors_animation_trigger.html#ab5d0f2ca30cc45d97f16f812ab0c32ca", null ]
];