var class_regenerate_dungeon_trigger_behaviour =
[
    [ "OnTriggerEnter", "class_regenerate_dungeon_trigger_behaviour.html#a7b085f39782bccbc034acb37170a4c00", null ],
    [ "runtimeGenerator", "class_regenerate_dungeon_trigger_behaviour.html#a12b52bc591b748abe98a2c3c27cbc32b", null ]
];