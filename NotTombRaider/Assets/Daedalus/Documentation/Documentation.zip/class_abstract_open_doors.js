var class_abstract_open_doors =
[
    [ "AnimateClose", "class_abstract_open_doors.html#aab68c26afc5895c1caf21b404be390d4", null ],
    [ "AnimateOpen", "class_abstract_open_doors.html#afd210dfb579cdddbd0a5ac392194ade3", null ]
];