var searchData=
[
  ['zones',['zones',['../class_physical_map.html#ae137bb25785bda8a8a5f17af4f9e94b0',1,'PhysicalMap']]]
];
