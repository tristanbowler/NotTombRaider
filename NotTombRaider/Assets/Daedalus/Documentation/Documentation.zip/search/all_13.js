var searchData=
[
  ['xy',['XY',['../_physical_map_8cs.html#aed0b9ae2cd84c53939012c28bf00f8d7a74c53bcd3dcb2bb79993b2fec37d362a',1,'PhysicalMap.cs']]],
  ['xz',['XZ',['../_physical_map_8cs.html#aed0b9ae2cd84c53939012c28bf00f8d7a27db3b98d01e664c17a6620b222c6469',1,'PhysicalMap.cs']]]
];
